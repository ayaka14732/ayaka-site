'use strict';

const fs = require('fs');
const Qieyun = require('qieyun');

const randList = [2468, 3238, 3708, 3811, 3223, 3064, 2479, 938, 3137, 3222, 2346, 1470, 2329, 3263, 1479, 1142, 520, 34, 2354, 843, 2159, 1193, 2471, 1707, 81, 633, 767, 2707, 2404, 2537, 2103, 1884, 1261, 409, 919, 2532, 129, 1071, 1869, 712, 229, 2957, 3797, 1899, 3453, 1407, 738, 2249, 3288, 1241, 593, 2587, 1415, 341, 1636, 822, 1379, 1548, 1919, 651, 1718, 3791, 1602, 1005, 3462, 3653, 1095, 1008, 1255, 686, 1612, 936, 3096, 3522, 1047, 579, 2750, 2953, 3205, 3099];

const first3000 = new Set(fs.readFileSync('first3000.txt', 'utf8'));
const after3000 = new Set(fs.readFileSync('after3000.txt', 'utf8'));

const srs = [939, 3290, 2226, 1090, 2230, 1381, 3203, 3291, 3430, 1933];

function srSimilarity(a, b) {
	let score = 0;
	if (Qieyun.get母(a) != Qieyun.get母(b)) score += 1;
	if (Qieyun.get開合(a) != Qieyun.get開合(b)) score += 1;
	if (Qieyun.get等(a) != Qieyun.get等(b)) score += 1;
	if (Qieyun.get韻賅上去入(a) != Qieyun.get韻賅上去入(b)) score += 1;
	if (Qieyun.get聲(a) != Qieyun.get聲(b)) score += 1;
	return score;
}

while (srs.length < 64) {
	const nextRand = randList.shift();
	if (!srs.some(sr => srSimilarity(nextRand, sr) <= 1))
		srs.push(nextRand);
}

function selectBestChar(xs) {
	let highestEver = 0, choice;
	for (const x of xs) {
		let score = 1;

		if (!first3000.has(x)) score += 1;
		if (after3000.has(x)) score += 1;
		if (x.length == 1) score += 1;

		if (score > highestEver) {
			highestEver = score;
			choice = x;
		}
	}
	return choice;
}

console.log('小韻號：' + JSON.stringify(srs.slice(10)));
console.log('漢字：' + srs.slice(10).map(sr => selectBestChar(Qieyun.query小韻號(sr).map(字頭_解釋 => 字頭_解釋[0]))).join(''));
